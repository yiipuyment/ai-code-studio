# 🚀 GitHub'a Yükleme Talimatları

Bu proje GitHub'a yüklenmeye hazır hale getirilmiştir. Aşağıdaki adımları takip ederek projenizi GitHub hesabınıza yükleyebilirsiniz.

## Seçenek 1: GitHub Web Interface (Önerilen)

### Adım 1: Yeni Repository Oluşturun
1. GitHub hesabınıza giriş yapın
2. Sağ üst köşedeki "+" butonuna tıklayın
3. "New repository" seçin
4. Repository adı: `ai-code-studio` (veya istediğiniz başka bir isim)
5. Description: "AI-powered code editor workspace"
6. **Public** veya **Private** seçin
7. **"Initialize this repository with a README" seçeneğini İŞARETLEMEYİN**
8. "Create repository" butonuna tıklayın

### Adım 2: Projeyi GitHub'a Yükleyin
GitHub'da oluşturduğunuz repository sayfasında gösterilen komutları kullanın:

```bash
cd /home/claude/ai-code-studio
git remote add origin https://github.com/KULLANICI_ADINIZ/ai-code-studio.git
git branch -M main
git push -u origin main
```

**Not:** `KULLANICI_ADINIZ` kısmını kendi GitHub kullanıcı adınızla değiştirin.

## Seçenek 2: GitHub CLI ile (Gelişmiş)

GitHub CLI yüklüyse:

```bash
cd /home/claude/ai-code-studio
gh repo create ai-code-studio --public --source=. --push
```

## Seçenek 3: GitHub Desktop ile

1. GitHub Desktop'ı açın
2. File → Add Local Repository
3. `/home/claude/ai-code-studio` klasörünü seçin
4. "Publish repository" butonuna tıklayın
5. Repository ismini ve açıklamayı ayarlayın
6. "Publish Repository" butonuna tıklayın

## Sonraki Adımlar

### 1. Environment Variables Ayarlayın
Repository'nizi oluşturduktan sonra:
1. GitHub repository sayfanıza gidin
2. Settings → Secrets and variables → Actions
3. "New repository secret" butonuna tıklayın
4. Aşağıdaki secret'ları ekleyin:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `GROQ_API_KEY`

### 2. Vercel'e Deploy Edin (Opsiyonel)
1. [Vercel](https://vercel.com) hesabınıza giriş yapın
2. "Import Project" butonuna tıklayın
3. GitHub repository'nizi seçin
4. Environment variables'ı `.env.example` dosyasından kopyalayıp ayarlayın
5. "Deploy" butonuna tıklayın

### 3. README'yi Güncelleyin
Repository URL'inizi eklemek için README.md dosyasını güncelleyebilirsiniz.

## Proje Yapısı

```
ai-code-studio/
├── app/                 # Next.js App Router
├── components/          # React bileşenleri
│   └── tabs/           # Tab bileşenleri
├── contexts/           # React Context
├── hooks/              # Custom hooks
├── lib/                # Yardımcı fonksiyonlar
├── public/             # Statik dosyalar
├── supabase/           # Supabase migrations
├── .env.example        # Environment variables şablonu
├── .gitignore          # Git ignore dosyası
├── package.json        # Proje bağımlılıkları
└── README.md           # Proje dokümantasyonu
```

## Güvenlik Notları

✅ `.env` dosyası `.gitignore`'a eklenmiştir
✅ API anahtarları güvenli bir şekilde saklanmaktadır
✅ `.env.example` dosyası şablon olarak eklenmiştir
✅ Hassas bilgiler commit edilmemiştir

## Sorun Giderme

### Problem: Git remote add hatası
```bash
# Mevcut remote'u kontrol edin
git remote -v

# Varsa önce kaldırın
git remote remove origin

# Yeniden ekleyin
git remote add origin YOUR_REPO_URL
```

### Problem: Push reddedildi
```bash
# Force push (dikkatli kullanın!)
git push -u origin main --force
```

### Problem: Authentication hatası
GitHub'da Personal Access Token oluşturun:
1. Settings → Developer settings → Personal access tokens
2. "Generate new token (classic)" butonuna tıklayın
3. `repo` scope'unu seçin
4. Token'ı kopyalayın ve şifre yerine kullanın

## Destek

Sorularınız için:
- GitHub Issues: Repository'nizde issue açın
- Email: support@aicodestudio.com

## Lisans

MIT License - Detaylar için LICENSE dosyasına bakın
